module.exports = require('./dist/index').style
