var id = 0;

export default function _classPrivateFieldLooseKey(name) {
    return "__private_" + id++ + "_" + name;
}
