function extends_() {
  extends_ = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return extends_.apply(this, arguments);
}

export default function _extends() {
  return extends_.apply(this, arguments);
}
