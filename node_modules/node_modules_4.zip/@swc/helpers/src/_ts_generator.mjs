export { __generator as default } from 'tslib'
